use warnings;
use strict;

use File::Basename qw(dirname);
use Cwd  qw(abs_path);
use lib dirname(dirname abs_path $0) . '/home/brenno/Documentos/Programing/Gerenciador-de-Senhas-mastar';

use funcoes qw(CheckBirthday NumericCharacters LowerCaseCharacters UpperCaseCharacters SpecialCharacters CheckName ReadAndAnalisys);

my $nameArq = $ARGV[0];
print "---------\n";

ReadAndAnalisys($nameArq);