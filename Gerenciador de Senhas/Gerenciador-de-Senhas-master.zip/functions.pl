#$_ NumericCharcters($password)
#sub-rotina que detecta a incidência de um ou mais caracteres numéricos[0-9]
sub NumericCharacters{
	my $classificacao;
    my @senha = @_;
	if($senha [0] =~ /\d/){
	  $classificacao = 1;
      return $classificacao;
	}

}
#$_ LowerCaseCharcters($password)
#sub-rotina que detecta a incidência de um ou mais caracteres alfabéticos minúsculos [a-z]
sub LowerCaseCharacters{
	my $classificacao;
	my @senha = @_;
	if($senha [0]  =~ /[a-z]/){
    	return $classificacao = 1;
	}
}
#$_ UpperCaseCharcters($password)
#sub-rotina que detecta a incidência de um ou mais caracteres alfabéticos maiúsculos [A-0]
sub UpperCaseCharacters{
  my $classificacao;
  my @senha = @_; 
	if($senha [0]  =~ /[A-Z]/){
	  return $classificacao = 1;
	}
}
#$_ SpecialCharcters($password)
#sub-rotina que detecta a incidência de um ou mais caracteres especiais [!@#$%&*_+|~^]
sub SpecialCharacters{
    my $classificacao;
    my @senha = @_;
	if($senha [0]  =~ /[!@#\$\%~^|&*_+]/){
	   return $classificacao = 2;   
	}
}
#$_ CheckBirthday($password, $birthday)
#sub-rotina que detecta a incidência da data de nascimento exclusivamente no final da senha 
sub CheckBirthday {
  my @nascimento = $_[1];
  my @senha = $_[0];
  if (index($senha [0], $nascimento [0]) != -1){
    return 1;
  }
} 

#$_ CheckName($password, $name)
#sub-rotina que detecta a incidência do nome exclusivamente no final da senha 
sub CheckName{
  my @nome = $_[1];
  my @senha = $_[0];
  if (index($senha [0], $nome [0]) != -1){
    return 1;
  }
}


# ReadAndAnalisys($nameArq)
#sub-rotina que abre o arquivo e realiza a analise sobre todo o arquivo de dados
sub ReadAndAnalisys{
	my @filename = @_;
	my @string;
	my $name;
	my $birthdate;
	my $password;
	my $relevance;
	open (my $fh , "<", $filename [0]) or die "Can't open  file\n"
	
	while (<$fh>){
	 @string = split (/\,+/,$_);
	 $name = $string [0];
	 $birthdate = $string [1];
	 $password = $string [2];
	 $relevance += &NumericCharacters ($password);
	 $relevance += &LowerCaseCharacters ($password);
	 $relevance += &UpperCaseCharacters ($password);
	 $relevance += &SpecialCharacters ($password);
	 print "Classificacao senha: $relevance ";
	 	if ($relevance <= 2){
	 			print "Senha fraca\n";
		}
		if($relevance == 3 || $relevance == 4) {
	 	  if (&CheckBirthday ($password, $birthdate) == 1||(&CheckName ($password, $name) == 1)){
	 		  print "Senha fraca contem data de nascimento e/ou aniversario\n";
	 	 }
		 else{
			print "Senha média\n";
		 }
		 
   	 }
	  if ($relevance == 5){
		print "Senha forte\n"
	  }
	  $relevance = 0;
	  print "---------\n";
	}
	
}	