use warnings;
use strict;

use functions qw(CheckBirthday NumericCharacters LowerCaseCharacters UpperCaseCharacters SpecialCharacters CheckName );


open  (my $in, "<", $ARGV[0]) or die "Arquivo nao pode ser aberto: $!";
my @string;
my $name;
my $birthdate;
my $password;
my $relevance = 0;
while (<$in>){
 @string = split (/\,+/,$_);
 $name = $string [0];
 $birthdate = $string [1];
 $password = $string [2];
 $relevance += &NumericCharacters ($password);
 $relevance += &LowerCaseCharacters ($password);
 $relevance += &UpperCaseCharacters ($password);
 $relevance += &SpecialCharacters ($password);
 print "Classificacao senha: $relevance ";
 if ($relevance <= 2){
 		print "Senha fraca\n";
	 }
 if($relevance == 3 || $relevance == 4) {
    if (&CheckBirthday ($password, $birthdate) == 1||(&CheckName ($password, $name) == 1)){
  		  print "Senha fraca contem data de nascimento e/ou aniversario\n";
    }
    else{
      print "Senha média\n";
    }
 }
 if ($relevance == 5){
 	print "Senha forte\n"
 }
   $relevance = 0;
   print "---------\n";
}
