package functions;

use 5.022001;
use strict;
use warnings;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use functions ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(CheckBirthday NumericCharacters LowerCaseCharacters UpperCaseCharacters SpecialCharacters CheckName
	
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
	
);

our $VERSION = '0.01';
#$_ NumericCharcters($password)
#sub-rotina que detecta a incidência de um ou mais caracteres numéricos[0-9]
sub NumericCharacters{
	my $classificacao;
    my @senha = @_;
	if($senha [0] =~ /\d/){
	  $classificacao = 1;
      return $classificacao;
	}

}
#$_ LowerCaseCharcters($password)
#sub-rotina que detecta a incidência de um ou mais caracteres alfabéticos minúsculos [a-z]
sub LowerCaseCharacters{
	my $classificacao;
	my @senha = @_;
	if($senha [0]  =~ /[a-z]/){
    	return $classificacao = 1;
	}
}
#$_ UpperCaseCharcters($password)
#sub-rotina que detecta a incidência de um ou mais caracteres alfabéticos maiúsculos [A-0]
sub UpperCaseCharacters{
  my $classificacao;
  my @senha = @_; 
	if($senha [0]  =~ /[A-Z]/){
	  return $classificacao = 1;
	}
}
#$_ SpecialCharcters($password)
#sub-rotina que detecta a incidência de um ou mais caracteres especiais [!@#$%&*_+|~^]
sub SpecialCharacters{
    my $classificacao;
    my @senha = @_;
	if($senha [0]  =~ /[!@#\$\%~^|&*_+]/){
	   return $classificacao = 2;   
	}
}
#$_ CheckBirthday($password, $birthday)
#sub-rotina que detecta a incidência da data de nascimento exclusivamente no final da senha 
sub CheckBirthday {
  my @nascimento = $_[1];
  my @senha = $_[0];
  if (index($senha [0], $nascimento [0]) != -1){
    return 1;
  }
} 

#$_ CheckName($password, $name)
#sub-rotina que detecta a incidência do nome exclusivamente no final da senha 
sub CheckName{
  my @nome = $_[1];
  my @senha = $_[0];
  if (index($senha [0], $nome [0]) != -1){
    return 1;
  }
}


	

# Preloaded methods go here.

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

functions - Perl extension for blah blah blah

=head1 SYNOPSIS

  use functions;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for functions, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

Brenno, E<lt>brenno@E<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2017 by Brenno

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.22.1 or,
at your option, any later version of Perl 5 you may have available.


=cut
